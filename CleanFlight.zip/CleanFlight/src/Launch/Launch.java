/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Launch;

import Gui.LoginFrame;


/**
 *
 * @author kiren
 */
public class Launch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    LoginFrame start = new LoginFrame();
 start.setVisible(true);

    }
    
}
